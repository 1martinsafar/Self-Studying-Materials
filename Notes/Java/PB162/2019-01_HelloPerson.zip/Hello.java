/*******************************************************************************
 * Třída {@code Hello} je hlavní třídou projektu,
 * který ...
 *
 * @author Tomáš Pitner
 * @version 0.00.0001 — 2019-09-17
 */
public class Hello {
    /***************************************************************************
     * Metoda, prostřednictvím níž se spouští celá aplikace.
     *
     * @param args Parametry příkazového řádku
     */
    public static void main(String[] args) {
        System.out.println("Ahoj!");
        
        Person petr = new Person("Petr Novák");
        
        System.out.println(petr.getName());
        
    }
}
